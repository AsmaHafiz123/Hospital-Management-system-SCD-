function handleSignup() {
    var userType = document.getElementById('userType').value;

    if (userType === 'patient') {
        // Redirect to the patient home page
        window.location.href = 'Home(Patient).html';
    } else if (userType === 'doctor') {
        // Redirect to the doctor verification page
        window.location.href = 'verification.html';
    }
}
